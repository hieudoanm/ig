/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

browser.runtime.onMessage.addListener((message) => {
    console.log('[IG Downloader BG] Received message:', message);
    if (message.action === 'download') {
        console.log('[IG Downloader BG] Initiating download for URL:', message.url);
        browser.downloads
            .download({
            url: message.url,
            filename: 'instagram_image.jpg',
            saveAs: true,
        })
            .then((downloadId) => {
            console.log(`[IG Downloader BG] Download started (ID: ${downloadId})`);
        })
            .catch((err) => {
            console.error('[IG Downloader BG] Download failed:', err);
        });
    }
    else {
        console.log('[IG Downloader BG] Ignored message with unknown action:', message.action);
    }
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0Esb0VBQW9FLFdBQVc7QUFDL0UsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGlnL2V4dGVuc2lvbi8uL3NyYy9iYWNrZ3JvdW5kLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuYnJvd3Nlci5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSkgPT4ge1xuICAgIGNvbnNvbGUubG9nKCdbSUcgRG93bmxvYWRlciBCR10gUmVjZWl2ZWQgbWVzc2FnZTonLCBtZXNzYWdlKTtcbiAgICBpZiAobWVzc2FnZS5hY3Rpb24gPT09ICdkb3dubG9hZCcpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ1tJRyBEb3dubG9hZGVyIEJHXSBJbml0aWF0aW5nIGRvd25sb2FkIGZvciBVUkw6JywgbWVzc2FnZS51cmwpO1xuICAgICAgICBicm93c2VyLmRvd25sb2Fkc1xuICAgICAgICAgICAgLmRvd25sb2FkKHtcbiAgICAgICAgICAgIHVybDogbWVzc2FnZS51cmwsXG4gICAgICAgICAgICBmaWxlbmFtZTogJ2luc3RhZ3JhbV9pbWFnZS5qcGcnLFxuICAgICAgICAgICAgc2F2ZUFzOiB0cnVlLFxuICAgICAgICB9KVxuICAgICAgICAgICAgLnRoZW4oKGRvd25sb2FkSWQpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKGBbSUcgRG93bmxvYWRlciBCR10gRG93bmxvYWQgc3RhcnRlZCAoSUQ6ICR7ZG93bmxvYWRJZH0pYCk7XG4gICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICAgICAgY29uc29sZS5lcnJvcignW0lHIERvd25sb2FkZXIgQkddIERvd25sb2FkIGZhaWxlZDonLCBlcnIpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbSUcgRG93bmxvYWRlciBCR10gSWdub3JlZCBtZXNzYWdlIHdpdGggdW5rbm93biBhY3Rpb246JywgbWVzc2FnZS5hY3Rpb24pO1xuICAgIH1cbn0pO1xuIl0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==