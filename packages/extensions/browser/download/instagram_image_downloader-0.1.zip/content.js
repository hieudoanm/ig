/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!************************!*\
  !*** ./src/content.ts ***!
  \************************/

document.addEventListener('dblclick', (e) => {
    const maxLevels = 3; // Change this number for how far to go up
    let target = e.target;
    let currentLevel = 0;
    console.log('[IG Downloader] Initial double-clicked element:', target);
    let img = null;
    while (target && currentLevel <= maxLevels) {
        if (target.tagName.toLowerCase() === 'img') {
            img = target;
            break;
        }
        const foundImg = target.querySelector('img');
        if (foundImg) {
            img = foundImg;
            break;
        }
        target = target.parentElement;
        currentLevel++;
    }
    if (!img) {
        console.log('[IG Downloader] No <img> element found after traversing upward.');
        return;
    }
    const url = img.src;
    console.log('[IG Downloader] Image URL detected:', url);
    // Send message to background script
    browser.runtime
        .sendMessage({ action: 'download', url })
        .then(() => {
        console.log('[IG Downloader] Message sent to background for download.');
    })
        .catch((err) => {
        console.error('[IG Downloader] Failed to send message:', err);
    });
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQSx5QkFBeUI7QUFDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSx1QkFBdUIseUJBQXlCO0FBQ2hEO0FBQ0E7QUFDQSxLQUFLO0FBQ0w7QUFDQTtBQUNBLEtBQUs7QUFDTCxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGlnL2V4dGVuc2lvbi8uL3NyYy9jb250ZW50LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIlwidXNlIHN0cmljdFwiO1xuZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignZGJsY2xpY2snLCAoZSkgPT4ge1xuICAgIGNvbnN0IG1heExldmVscyA9IDM7IC8vIENoYW5nZSB0aGlzIG51bWJlciBmb3IgaG93IGZhciB0byBnbyB1cFxuICAgIGxldCB0YXJnZXQgPSBlLnRhcmdldDtcbiAgICBsZXQgY3VycmVudExldmVsID0gMDtcbiAgICBjb25zb2xlLmxvZygnW0lHIERvd25sb2FkZXJdIEluaXRpYWwgZG91YmxlLWNsaWNrZWQgZWxlbWVudDonLCB0YXJnZXQpO1xuICAgIGxldCBpbWcgPSBudWxsO1xuICAgIHdoaWxlICh0YXJnZXQgJiYgY3VycmVudExldmVsIDw9IG1heExldmVscykge1xuICAgICAgICBpZiAodGFyZ2V0LnRhZ05hbWUudG9Mb3dlckNhc2UoKSA9PT0gJ2ltZycpIHtcbiAgICAgICAgICAgIGltZyA9IHRhcmdldDtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZvdW5kSW1nID0gdGFyZ2V0LnF1ZXJ5U2VsZWN0b3IoJ2ltZycpO1xuICAgICAgICBpZiAoZm91bmRJbWcpIHtcbiAgICAgICAgICAgIGltZyA9IGZvdW5kSW1nO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgdGFyZ2V0ID0gdGFyZ2V0LnBhcmVudEVsZW1lbnQ7XG4gICAgICAgIGN1cnJlbnRMZXZlbCsrO1xuICAgIH1cbiAgICBpZiAoIWltZykge1xuICAgICAgICBjb25zb2xlLmxvZygnW0lHIERvd25sb2FkZXJdIE5vIDxpbWc+IGVsZW1lbnQgZm91bmQgYWZ0ZXIgdHJhdmVyc2luZyB1cHdhcmQuJyk7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgdXJsID0gaW1nLnNyYztcbiAgICBjb25zb2xlLmxvZygnW0lHIERvd25sb2FkZXJdIEltYWdlIFVSTCBkZXRlY3RlZDonLCB1cmwpO1xuICAgIC8vIFNlbmQgbWVzc2FnZSB0byBiYWNrZ3JvdW5kIHNjcmlwdFxuICAgIGJyb3dzZXIucnVudGltZVxuICAgICAgICAuc2VuZE1lc3NhZ2UoeyBhY3Rpb246ICdkb3dubG9hZCcsIHVybCB9KVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbSUcgRG93bmxvYWRlcl0gTWVzc2FnZSBzZW50IHRvIGJhY2tncm91bmQgZm9yIGRvd25sb2FkLicpO1xuICAgIH0pXG4gICAgICAgIC5jYXRjaCgoZXJyKSA9PiB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tJRyBEb3dubG9hZGVyXSBGYWlsZWQgdG8gc2VuZCBtZXNzYWdlOicsIGVycik7XG4gICAgfSk7XG59KTtcbiJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=