/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/*!***************************!*\
  !*** ./src/background.ts ***!
  \***************************/

browser.runtime.onMessage.addListener((message) => {
    console.log('[IG Downloader BG] Received message:', message);
    if (message.action === 'download') {
        console.log('[IG Downloader BG] Initiating download for URL:', message.url);
        browser.downloads
            .download({
            url: message.url,
            filename: 'instagram_image.jpg',
            saveAs: true,
        })
            .then((downloadId) => {
            console.log(`[IG Downloader BG] Download started (ID: ${downloadId})`);
        })
            .catch((err) => {
            console.error('[IG Downloader BG] Download failed:', err);
        });
    }
    else {
        console.log('[IG Downloader BG] Ignored message with unknown action:', message.action);
    }
});

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUztBQUNUO0FBQ0Esb0VBQW9FLFdBQVc7QUFDL0UsU0FBUztBQUNUO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGluc3RhZ3JhbS9leHRlbnNpb24vLi9zcmMvYmFja2dyb3VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJcInVzZSBzdHJpY3RcIjtcbmJyb3dzZXIucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UpID0+IHtcbiAgICBjb25zb2xlLmxvZygnW0lHIERvd25sb2FkZXIgQkddIFJlY2VpdmVkIG1lc3NhZ2U6JywgbWVzc2FnZSk7XG4gICAgaWYgKG1lc3NhZ2UuYWN0aW9uID09PSAnZG93bmxvYWQnKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdbSUcgRG93bmxvYWRlciBCR10gSW5pdGlhdGluZyBkb3dubG9hZCBmb3IgVVJMOicsIG1lc3NhZ2UudXJsKTtcbiAgICAgICAgYnJvd3Nlci5kb3dubG9hZHNcbiAgICAgICAgICAgIC5kb3dubG9hZCh7XG4gICAgICAgICAgICB1cmw6IG1lc3NhZ2UudXJsLFxuICAgICAgICAgICAgZmlsZW5hbWU6ICdpbnN0YWdyYW1faW1hZ2UuanBnJyxcbiAgICAgICAgICAgIHNhdmVBczogdHJ1ZSxcbiAgICAgICAgfSlcbiAgICAgICAgICAgIC50aGVuKChkb3dubG9hZElkKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhgW0lHIERvd25sb2FkZXIgQkddIERvd25sb2FkIHN0YXJ0ZWQgKElEOiAke2Rvd25sb2FkSWR9KWApO1xuICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKChlcnIpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoJ1tJRyBEb3dubG9hZGVyIEJHXSBEb3dubG9hZCBmYWlsZWQ6JywgZXJyKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZygnW0lHIERvd25sb2FkZXIgQkddIElnbm9yZWQgbWVzc2FnZSB3aXRoIHVua25vd24gYWN0aW9uOicsIG1lc3NhZ2UuYWN0aW9uKTtcbiAgICB9XG59KTtcbiJdLCJuYW1lcyI6W10sImlnbm9yZUxpc3QiOltdLCJzb3VyY2VSb290IjoiIn0=